package com.quickpharma.services;

import java.util.List;

import com.quickpharma.dtos.PlaceOrderDTO;
import com.quickpharma.entities.Order;
import com.quickpharma.entities.User;

public interface OrderService {
	
	//public Order saveOrder(PlaceOrderDTO orderDto, User user); my code
	

}
