package com.quickpharma.dtos;


public class OrderItemDTO {
    private double price;
    private int quantity;
    private int orderId;
    private int productId;

    public OrderItemDTO () {}

	public OrderItemDTO(double price, int quantity, int orderId, int productId) {
		super();
		this.price = price;
		this.quantity = quantity;
		this.orderId = orderId;
		this.productId = productId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	@Override
	public String toString() {
		return "OrderItemDTO [price=" + price + ", quantity=" + quantity + ", orderId=" + orderId + ", productId="
				+ productId + "]";
	}

   
	

}